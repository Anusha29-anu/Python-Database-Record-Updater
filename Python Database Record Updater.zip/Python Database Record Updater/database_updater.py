import sqlite3
import sys
from typing import Optional, Tuple

class DatabaseUpdater:
    """
    A class to handle database connections and record updates.
    This example uses SQLite (built into Python standard library).
    """
    
    def __init__(self, database_path: str = "example.db"):
        """Initialize with database path"""
        self.database_path = database_path
        self.connection = None
    
    def connect(self) -> bool:
        """Establish database connection"""
        try:
            self.connection = sqlite3.connect(self.database_path)
            self.connection.row_factory = sqlite3.Row  # Enable column access by name
            print(f"✅ Successfully connected to database: {self.database_path}")
            return True
        except sqlite3.Error as e:
            print(f"❌ Error connecting to database: {e}")
            return False
    
    def disconnect(self):
        """Close database connection"""
        if self.connection:
            self.connection.close()
            print("🔌 Database connection closed")
    
    def create_sample_table(self):
        """Create a sample table for demonstration"""
        try:
            cursor = self.connection.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS employees (
                    id INTEGER PRIMARY KEY,
                    name TEXT NOT NULL,
                    department TEXT,
                    salary REAL,
                    email TEXT
                )
            """)
            
            # Insert sample data if table is empty
            cursor.execute("SELECT COUNT(*) FROM employees")
            if cursor.fetchone()[0] == 0:
                sample_data = [
                    (1, "John Doe", "Engineering", 75000.0, "john.doe@company.com"),
                    (2, "Jane Smith", "Marketing", 65000.0, "jane.smith@company.com"),
                    (3, "Bob Johnson", "Engineering", 80000.0, "bob.johnson@company.com"),
                    (4, "Alice Brown", "HR", 60000.0, "alice.brown@company.com")
                ]
                cursor.executemany(
                    "INSERT INTO employees (id, name, department, salary, email) VALUES (?, ?, ?, ?, ?)",
                    sample_data
                )
                self.connection.commit()
                print("📊 Sample data inserted into employees table")
            
            print("✅ Sample table 'employees' ready")
            
        except sqlite3.Error as e:
            print(f"❌ Error creating sample table: {e}")
    
    def show_table_contents(self, table_name: str):
        """Display current table contents"""
        try:
            cursor = self.connection.cursor()
            cursor.execute(f"SELECT * FROM {table_name}")
            rows = cursor.fetchall()
            
            if rows:
                print(f"\n📋 Current contents of '{table_name}' table:")
                print("-" * 80)
                # Print column headers
                columns = [description[0] for description in cursor.description]
                header = " | ".join(f"{col:12}" for col in columns)
                print(header)
                print("-" * 80)
                
                # Print rows
                for row in rows:
                    row_str = " | ".join(f"{str(val):12}" for val in row)
                    print(row_str)
                print("-" * 80)
            else:
                print(f"📝 Table '{table_name}' is empty")
                
        except sqlite3.Error as e:
            print(f"❌ Error displaying table contents: {e}")
    
    def update_records(self, table_name: str, column: str, new_value: str, 
                      condition_column: str, condition_value: str) -> Tuple[bool, int]:
        """
        Update records in the specified table
        
        Args:
            table_name: Name of the table to update
            column: Column to update
            new_value: New value to set
            condition_column: Column to use in WHERE clause
            condition_value: Value to match in WHERE clause
            
        Returns:
            Tuple of (success: bool, affected_rows: int)
        """
        try:
            cursor = self.connection.cursor()
            
            # Construct the UPDATE query
            query = f"UPDATE {table_name} SET {column} = ? WHERE {condition_column} = ?"
            
            print(f"\n🔄 Executing update query:")
            print(f"   UPDATE {table_name} SET {column} = '{new_value}' WHERE {condition_column} = '{condition_value}'")
            
            # Execute the update
            cursor.execute(query, (new_value, condition_value))
            affected_rows = cursor.rowcount
            
            # Commit the transaction
            self.connection.commit()
            
            if affected_rows > 0:
                print(f"✅ Update successful! {affected_rows} row(s) affected")
                return True, affected_rows
            else:
                print(f"⚠️  No rows were updated. Check if the condition matches any records.")
                return True, 0
                
        except sqlite3.Error as e:
            print(f"❌ Error updating records: {e}")
            self.connection.rollback()
            return False, 0
    
    def validate_table_and_columns(self, table_name: str, columns: list) -> bool:
        """Validate that table and columns exist"""
        try:
            cursor = self.connection.cursor()
            
            # Check if table exists
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table_name,))
            if not cursor.fetchone():
                print(f"❌ Table '{table_name}' does not exist")
                return False
            
            # Check if columns exist
            cursor.execute(f"PRAGMA table_info({table_name})")
            existing_columns = [row[1] for row in cursor.fetchall()]
            
            for column in columns:
                if column not in existing_columns:
                    print(f"❌ Column '{column}' does not exist in table '{table_name}'")
                    print(f"Available columns: {', '.join(existing_columns)}")
                    return False
            
            return True
            
        except sqlite3.Error as e:
            print(f"❌ Error validating table/columns: {e}")
            return False

def get_user_input():
    """Get update parameters from user input"""
    print("\n" + "="*60)
    print("🔧 DATABASE RECORD UPDATER")
    print("="*60)
    
    table_name = input("Enter table name: ").strip()
    if not table_name:
        print("❌ Table name cannot be empty")
        return None
    
    column = input("Enter column to update: ").strip()
    if not column:
        print("❌ Column name cannot be empty")
        return None
    
    new_value = input("Enter new value: ").strip()
    
    condition_column = input("Enter condition column (WHERE clause): ").strip()
    if not condition_column:
        print("❌ Condition column cannot be empty")
        return None
    
    condition_value = input("Enter condition value: ").strip()
    if not condition_value:
        print("❌ Condition value cannot be empty")
        return None
    
    return {
        'table_name': table_name,
        'column': column,
        'new_value': new_value,
        'condition_column': condition_column,
        'condition_value': condition_value
    }

def main():
    """Main function to run the database updater"""
    print("🚀 Starting Database Record Updater")
    
    # Initialize database connection
    db_updater = DatabaseUpdater("company.db")
    
    if not db_updater.connect():
        print("❌ Failed to connect to database. Exiting.")
        return
    
    try:
        # Create sample table and data for demonstration
        db_updater.create_sample_table()
        
        while True:
            # Show current table contents
            db_updater.show_table_contents("employees")
            
            # Get user input
            update_params = get_user_input()
            if not update_params:
                continue
            
            # Validate table and columns exist
            columns_to_check = [update_params['column'], update_params['condition_column']]
            if not db_updater.validate_table_and_columns(update_params['table_name'], columns_to_check):
                continue
            
            # Perform the update
            success, affected_rows = db_updater.update_records(
                update_params['table_name'],
                update_params['column'],
                update_params['new_value'],
                update_params['condition_column'],
                update_params['condition_value']
            )
            
            if success:
                print(f"\n🎉 Update operation completed successfully!")
                if affected_rows > 0:
                    # Show updated table contents
                    print(f"\n📊 Updated table contents:")
                    db_updater.show_table_contents(update_params['table_name'])
            
            # Ask if user wants to continue
            print("\n" + "-"*60)
            continue_choice = input("Would you like to perform another update? (y/n): ").strip().lower()
            if continue_choice not in ['y', 'yes']:
                break
    
    except KeyboardInterrupt:
        print("\n\n🛑 Program interrupted by user")
    
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
    
    finally:
        # Clean up
        db_updater.disconnect()
        print("👋 Database updater finished")

if __name__ == "__main__":
    main()