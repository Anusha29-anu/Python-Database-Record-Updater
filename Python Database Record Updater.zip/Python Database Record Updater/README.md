# Python Database Record Updater

This program demonstrates how to connect to a database and update records using Python and SQL queries.

## Features

- ✅ Database connection management
- 📊 Display current table contents
- 🔧 Interactive record updates
- ✅ Input validation and error handling
- 🛡️ SQL injection prevention using parameterized queries
- 📋 Confirmation of successful updates

## Current Implementation

Since this environment has Python limited to standard library only, the program uses **SQLite** (built into Python). The program creates a sample `employees` table for demonstration.

## Usage

Run the main program:
```bash
python database_updater.py
```

The program will:
1. Create a sample database with employee records
2. Show the current table contents
3. Prompt you to specify:
   - Table name
   - Column to update
   - New value
   - Condition column (for WHERE clause)
   - Condition value

## Example Updates

Sample updates you can try:
- Update John Doe's salary to 85000
- Change Jane Smith's department to "Sales"
- Update Bob Johnson's email address

## MySQL Implementation

For production use with MySQL, see `mysql_example.py` which shows the structure for:
- MySQL connection using `mysql-connector-python`
- Same update logic with MySQL-specific syntax
- Proper parameter binding for MySQL

## Security Features

- ✅ Parameterized queries prevent SQL injection
- ✅ Input validation
- ✅ Transaction rollback on errors
- ✅ Table/column existence validation

## File Structure

- `database_updater.py` - Main SQLite implementation
- `mysql_example.py` - MySQL implementation example
- `company.db` - SQLite database (created automatically)